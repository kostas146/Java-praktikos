import weka.classifiers.bayes.NaiveBayes;
import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;
import weka.classifiers.Evaluation;
import weka.core.DenseInstance;
import weka.core.Instance;
import weka.core.Attribute;
import java.util.ArrayList;
import weka.classifiers.Classifier;

import java.io.IOException;

class WekaExample {

    public static void main(String[] args) {
        try {
            // Load a dataset (ARFF format)
            DataSource source = new DataSource("C:/Sauguma4/Intelektika/Weka_test/telefonai.arff");
            Instances dataset = source.getDataSet();

            // Set the class index (the attribute to be predicted)
            dataset.setClassIndex(dataset.numAttributes() - 1);

            // Split the dataset into training and testing sets
            dataset.randomize(new java.util.Random(0));
            Instances trainingSet = dataset.trainCV(3, 0);
            Instances testingSet = dataset.testCV(3, 0);

            // Train a NaiveBayes classifier on the training set
            NaiveBayes classifier = new NaiveBayes();
            classifier.buildClassifier(trainingSet);
            EvaluationUtils.evaluateClassifier(classifier, dataset, 3);
            // Use the trained classifier to predict the class labels of the instances in the testing set
            Evaluation evaluation = new Evaluation(testingSet);
            evaluation.evaluateModel(classifier, testingSet);


            // Create a new instance to classify
            ArrayList<Attribute> attrs = new ArrayList<Attribute>();
            attrs.add(new Attribute("ekrano_dydis"));
            attrs.add(new Attribute("baterijos_talpa"));
            attrs.add(new Attribute("kamera_megapikseliai"));
            attrs.add(new Attribute("atmintis_gigabaitais"));
            ArrayList<String> classValues = new ArrayList<String>();
            classValues.add("Zema");
            classValues.add("Vidutine");
            classValues.add("Auksta");
            Attribute classAttr = new Attribute("kaina", classValues);
            attrs.add(classAttr);
            Instances instances = new Instances("Test", attrs, 0);
            instances.setClass(classAttr);
            Instance instance = new DenseInstance(5);
            instance.setDataset(instances);
            instance.setValue(0, 6.1); // set the value for the "ekrano_dydis" attribute to 6.1
            instance.setValue(1, 3000); // set the value for the "baterijos_talpa" attribute to 3000
            instance.setValue(2, 20); // set the value for the "kamera_megapikseliai" attribute to 20
            instance.setValue(3, 128); // set the value for the "atmintis_gigabaitais" attribute to 128
            instance.setClassMissing();
            instances.add(instance);

            // Classify the instance using the trained classifier
            double[] distribution = classifier.distributionForInstance(instance);
            double maxProb = -1;
            int maxIndex = -1;
            for (int i = 0; i < distribution.length; i++) {
                if (distribution[i] > maxProb) {
                    maxProb = distribution[i];
                    maxIndex = i;
                }
            }
            System.out.println("Predicted phone on given parameters: " + dataset.classAttribute().value(maxIndex));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}




 class EvaluationUtils {

     static void evaluateClassifier(Classifier classifier, Instances data, int numFolds) {
        try {
            // Set the class index (the attribute to be predicted)
            data.setClassIndex(data.numAttributes() - 1);

            // Perform cross-validation
            Evaluation evaluation = new Evaluation(data);
            evaluation.crossValidateModel(classifier, data, numFolds, new java.util.Random(1));

            // Print the accuracy and mean classification time
            System.out.println("Accuracy: " + evaluation.pctCorrect() + "%");
            long totalTime = 0;
            for (int i = 0; i < data.numInstances(); i++) {
                long startTime = System.nanoTime();
                evaluation.evaluateModelOnceAndRecordPrediction(classifier, data.instance(i));
                long endTime = System.nanoTime();
                totalTime += endTime - startTime;
            }
            double meanTime = totalTime / (double) data.numInstances() / 1000000; // convert to milliseconds
            System.out.println("Mean classification time per instance: " + meanTime + " ms");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
