import weka.attributeSelection.InfoGainAttributeEval;
import weka.classifiers.bayes.NaiveBayes;
import weka.core.*;
import weka.core.converters.ConverterUtils.DataSource;

import java.util.*;
import java.util.Queue;

class GuessTheAnimal  {
    public static void main(String[] args) throws Exception {
        // Įkeliame gyvūnų duomenų rinkinį iš failo
        Instances gyvunuDataset = įkeltiGyvunuDataset();

        // Trenirujame Naive Bayes modelį duomenų rinkinyje
        NaiveBayes modelis = treniruotiNaiveBayesModeli(gyvunuDataset);

        // Naudojame BFS, kad rastume optimalų klausimo eiliškumą
        Queue<Attribute> klausimoEile = bfs(gyvunuDataset);

        // Klausiame vartotojo, kad atspėtume gyvūną
        Scanner skaneris = new Scanner(System.in);
        Instance egzempliorius = new DenseInstance(gyvunuDataset.numAttributes());
        egzempliorius.setDataset(gyvunuDataset);

        // Klausiame vartotojui, kol klausimo eilė nėra tuščia
        while (!klausimoEile.isEmpty()) {
            // Ištraukiame kitą klausimą iš prioritetinės eilės
            Attribute atributas = klausimoEile.remove();
            System.out.print(atributas.name() + "? Galimos reikšmės: ");

            // Jeigu atributas yra nominalus, rodomos visas galimas reikšmes
            if (atributas.isNominal()) {
                for (int i = 0; i < atributas.numValues(); i++) {
                    System.out.print(atributas.value(i));
                    if (i < atributas.numValues() - 1) {
                        System.out.print(", ");
                    }
                }
                System.out.print(" ");
                // Jeigu atributas yra skaitinis, rodoma, kad reikšmė turi būti skaitinė
            } else if (atributas.isNumeric()) {
                System.out.print("skaitinė ");
            }

            // Nuskaitomas vartotojo atsakymas
            String atsakymas = skaneris.nextLine();

            // Patikrinama, ar vartotojo atsakymas yra teisingas
            if (atributas.isNominal() && atributas.indexOfValue(atsakymas) != -1) {
                // Jeigu atsakymas yra nominalus ir yra tarp galimų reikšmių, atsakymas įrašomas į egzempliorių
                egzempliorius.setValue(atributas, atsakymas);
            } else if (atributas.isNumeric() && yraSkaitinė(atsakymas)) {
                // Jeigu atsakymas yra skaitinis ir yra teisingas skaičius, atsakymas įrašomas į egzempliorių
                egzempliorius.setValue(atributas, Double.parseDouble(atsakymas));
            } else {
                // Kitu atveju vartotojui pranešama, kad atsakymas neteisingas, ir klausimas pakartojamas
                System.out.println("Neteisingas atsakymas, prašome įvesti teisingą reikšmę.");
                klausimoEile.add(atributas);
            }
        }


        double prognozė = modelis.classifyInstance(egzempliorius);
        String numatomasGyvūnas = gyvunuDataset.classAttribute().value((int) prognozė);

        // Rodyti vartotojui numatytą gyvūną
        System.out.println("Gyvūnas yra " + numatomasGyvūnas + "!");
    }

    private static Instances įkeltiGyvunuDataset() throws Exception {
        // Įkeliam gyvūnų duomenų rinkinį iš failo
        DataSource šaltinis = new DataSource("C:/Sauguma4/Intelektika/Guess/Animalke.arff");
        Instances dataset = šaltinis.getDataSet();
        dataset.setClassIndex(dataset.numAttributes() - 1);
        return dataset;
    }

    private static NaiveBayes treniruotiNaiveBayesModeli(Instances dataset) throws Exception {
        NaiveBayes modelis = new NaiveBayes();
        modelis.buildClassifier(dataset);
        return modelis;
    }

    private static Queue<Attribute> bfs(Instances gyvunuDataset) throws Exception {
        // Atskiriame atributus nuo klasės atributo
        int numAtributai = gyvunuDataset.numAttributes() - 1;

        // Sukuriame prioritetinę eilę, kurioje atributai bus išdėstyti pagal informacijos gain vertę
        PriorityQueue<Attribute> klausimoEile = new PriorityQueue<>(numAtributai, new Comparator<Attribute>() {
            @Override
            public int compare(Attribute a1, Attribute a2) {
                try {
                    // Atskaičiuojame informacijos gain vertes kiekvienam atributui
                    InfoGainAttributeEval eval = new InfoGainAttributeEval();
                    eval.buildEvaluator(gyvunuDataset);
                    double infoGain1 = eval.evaluateAttribute(a1.index());
                    double infoGain2 = eval.evaluateAttribute(a2.index());

                    // Rūšiuojame atributus pagal informacijos gain vertes
                    return Double.compare(infoGain2, infoGain1);
                } catch (Exception e) {
                    e.printStackTrace();
                    return 0;
                }
            }
        });

        // Įtraukiame visus atributus į prioritetinę eilę, išskyrus klasės atributą
        for (int i = 0; i < numAtributai; i++) {
            Attribute atributas = gyvunuDataset.attribute(i);
            if (!atributas.equals(gyvunuDataset.classAttribute())) {
                klausimoEile.add(atributas);
            }
        }

        // Gražiname prioritetinę eilę
        return klausimoEile;
    }

    /**
     * Šis metodas patikrina, ar tekstinė reikšmė yra skaitinė.
     * @param str - Tekstinė reikšmė, kurią norime patikrinti
     * @return true, jei tekstinė reikšmė yra skaitinė, false kitu atveju
     */
    private static boolean yraSkaitinė(String str) {
        try {
            Double.parseDouble(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

}
