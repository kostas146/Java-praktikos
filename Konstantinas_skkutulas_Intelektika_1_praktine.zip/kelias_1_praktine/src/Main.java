import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;

class Main {
    // Sukuriamas žemėlapis, kuriame saugomi ryšiai tarp šalių
    static Map<String, ArrayList<String>> zemelapis = new HashMap<>();

    // Metodas skirtas pridėti ryšį tarp šalių
    static void pridetiSiena(String pradziosSalis, String pabaigosSalis) {
        if (!zemelapis.containsKey(pradziosSalis)) {
            zemelapis.put(pradziosSalis, new ArrayList<>());
        }
        zemelapis.get(pradziosSalis).add(pabaigosSalis);
    }

    // BFS algoritmas skirtas surasti trumpiausią kelią tarp šalių
    static ArrayList<String> bfs(String pradziosSalis, String pabaigosSalis) {
        // Map objektas skirtas saugoti praeitas šalis
        Map<String, String> praeitas = new HashMap<>();
        // Queue objektas skirtas saugoti būsimas šalis
        Queue<String> eilė = new LinkedList<>();

        // Pradėti paiešką nuo pradžios šalies
        eilė.add(pradziosSalis);
        while (!eilė.isEmpty()) {
            // Imama dabartinė šalis iš eilės
            String dabartinė = eilė.poll();
            // Jeigu dabartinė šalis yra pabaigos šalis, tai gražinamas kelias
            if (dabartinė.equals(pabaigosSalis)) {
                ArrayList<String> kelias = new ArrayList<>();
                while (dabartinė != null) {
                    kelias.add(0, dabartinė);
                    dabartinė = praeitas.get(dabartinė);
                }
                return kelias;
            }
            // Patikrinama ar dabartinė šalis turi
// sąsajas su kitais šalimis
            for (String kaimynas : zemelapis.getOrDefault(dabartinė, new ArrayList<>())) {
// Jeigu šalis dar nebuvo aplankyta, tai ji įtraukiama į eilę ir įrašoma kaip praeita šalis
                if (!praeitas.containsKey(kaimynas)) {
                    praeitas.put(kaimynas, dabartinė);
                    eilė.add(kaimynas);
                }
            }
        }
// Gražinamas tuščias kelias, jeigu kelias tarp šalių nerastas
        return new ArrayList<>();
    }

    public static void main(String[] args) {
        pridetiSiena("Vilnius", "Kaunas");
        pridetiSiena("Kaunas", "Klaipėda");
        pridetiSiena("Kaunas", "Šiauliai");
        pridetiSiena("Klaipėda", "Palanga");
        pridetiSiena("Šiauliai", "Panevėžys");
        pridetiSiena("Vilnius", "Alytus");
        pridetiSiena("Alytus", "Marijampolė");
        pridetiSiena("Vilnius", "Utena");
        pridetiSiena("Utena", "Kėdainiai");
        pridetiSiena("Kėdainiai", "Jonava");
        pridetiSiena("Jonava", "Joniškis");
        pridetiSiena("Joniškis", "Kaunas");
        pridetiSiena("Panevėžys", "Rokiškis");
        pridetiSiena("Rokiškis", "Biržai");
        pridetiSiena("Biržai", "Kupiškis");
        pridetiSiena("Kupiškis", "Pasvalys");
        pridetiSiena("Pasvalys", "Raseiniai");
        pridetiSiena("Raseiniai", "Kelmė");
        pridetiSiena("Kelmė", "Plungė");
        pridetiSiena("Plungė", "Telšiai");
        pridetiSiena("Telšiai", "Mažeikiai");
        pridetiSiena("Mažeikiai", "Kretinga");
        ArrayList<String> kelias = bfs("Vilnius", "Kretinga");
        System.out.println("Trumpiausias kelias tarp Vilniaus ir Kretingos: " + kelias);
    }
}